from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import yaml

raw = Path('/tmp/p2a-followup/b0')
repo = Path('/home/aim06/projects/2026-2-kcity-autonomous-driving/2026-ai-sw-mobility-competition/asmc-camera-objects')
out = repo/'config/baselines/evidence/camera_lidar_b0_v1'
out.mkdir(parents=True, exist_ok=True)
fixed = raw/'protocol-299a21a'
summary = json.loads((fixed/'summary.json').read_text())
supp = raw/'supplemental-f293276'
extra = json.loads((supp/'index.json').read_text())
assert summary['protocol_complete'] and len(extra) == 9 and all(r['report_exists'] for r in extra)
manifest = json.loads((fixed/'manifest.json').read_text())
reports = [r['report'] for r in summary['trials'] if not r['diagnostic']]
def read(name):
    return json.loads((raw/name).read_text())
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda: stream.read(4194304), b''):
            h.update(b)
    return h.hexdigest()

camera = {}
for profile in ('C1', 'C2', 'C3', 'C4', 'C5', 'C6'):
    rows = sorted([r for r in reports if r['phase'] == 'camera' and not r['camera_debug'] and r['profile'] == profile], key=lambda r:r['repeat'])
    camera[profile] = dict(passed=[r['passed'] for r in rows],
        outputs={key:{metric:[r['measurements'][key][metric] for r in rows]
            for metric in ('hz','first_second','five_second_hz','max_gap_sec','valid_ratio','duplicate_stamps','reversed_stamps','source_age_ms','input_to_output_wall_ms')}
            for key in rows[0]['measurements']},
        gpu_p95_percent=[r['resources']['gpu_utilization_percent']['p95'] for r in rows],
        gpu_sampled_max_memory_mib=[r['resources']['gpu_memory_mib']['maximum'] for r in rows])
fusion = {}
for label, comparison in summary['fusion_comparisons'].items():
    bag, profile = label.split('-')
    rows = sorted([r for r in reports if r['phase']=='fusion' and r['bag_id']==bag and r['profile']==profile],key=lambda r:r['repeat'])
    stable = comparison['stable_observations']
    fusion[label] = dict(matched=[r['fusion']['totals']['matched'] for r in rows],
        processed=[len(r['fusion']['published_processed_lidar_stamps_ns']) for r in rows],
        dropped=[r['fusion']['totals']['dropped'] for r in rows],
        shutdown_pending=[r['fusion']['pending_end'] for r in rows],
        offset_p95_max_interval_ms=[r['fusion']['offset_p95_max_ms'] for r in rows],
        absolute_count_gate_pass=comparison['matched_not_degraded'],
        common_stable_classification_gate_pass=comparison['classification_gate_pass'],
        stable_corresponded_observations=stable['old_stable'],
        stable_classification_differences=len(stable['regressions']),
        unmatched_common_observations=stable['unmatched_common_observations'])
gps = [r for r in reports if r['phase']=='gps' and r['gps_gap']]
cpu = read('cpu-environment.json')
baseline = dict(schema_version=1, baseline_id='perception_camera_lidar_b0_v1', recorded_on='2026-10-07',
    status='complete_measurement_and_failure_baseline',
    base_main='3b142b176ee904f1bbefe4546057a4ba62a1dccb',
    branch='feat/camera-performance-comparison', measured_runtime_revision='299a21a81bcb76ba87fdba68d7c2035128132e7e',
    supplemental_runner_revision='f293276', operational_defaults_changed=False, configuration_adoption='none',
    environment=dict(gpu=manifest['gpu'], container_image=read('container-manifest.json')['image_id'],
        cpu_model=cpu['cpu_model'], cpu_affinity=cpu['available_cpu_affinity'], cgroup_limits=cpu['cgroup_limits'],
        network='none', ros_master_port=11312, simulator='stopped_verified_by_process_queries',
        shared_live_master_or_bridge_changed=False, windows_desktop_gpu_memory_included=True,
        gpu_process_memory='unavailable', resource_interval_sec=.2, sampled_peak_is_not_instantaneous_peak=True,
        full_competition_stack_claim=False, python=manifest['python'], interpreter=manifest['interpreter'],
        versions=read('supplemental-versions.json')),
    fixed_protocol=dict(expected=51, completed=51, individual_checks_passed=49,
        individual_checks_failed=summary['performance_failed_trials'],
        camera=18, fusion=24, gps_diagnostic=6, debug_comparison=3,
        lifecycle_trace_diagnostics=2, supplemental_fusion_trace_diagnostics=8, supplemental_clean_C2=1,
        total_completed_final_bundle=62, acceptance_rate_checks_trace_enabled=False,
        failed_traces_or_successes_do_not_replace_original_trials=True),
    method=dict(all_models_resident=True, target_hz=dict(twinlite=10,yolo=20,resnet18=10),
        yolo_views=['front'], twinlite_views=['front','left','right'], resnet_view='extra',
        yolo_weights_sha256=manifest['weight_sha256']['src/asmc_camera/models/object_detection/yolo11m.pt'],
        hood_mask_sha256='4e94448bca0b5081e53411c5450938074d69bc223166cb173a41b8f80a210403',
        hood_mask_enabled=True, ego_hood_filter_enabled=False, lidar_rate='existing_latest_frame_maximum',
        fusion_offset_sec=.05, fusion_wait_sec=.20, first_second_anchor='RPC_start_conservative_in_untraced_trials',
        complete_20_second_transition_windows=True, full_bag_rate_end='corresponding_last_camera_input_received',
        main_intrinsic_fusion_debug='always_retained_existing_operation',
        camera_debug_off_in_normal_measurements=True, legacy_main_control='quarantined_test_namespace',
        final_shutdown_accounting_verified=True, classification_identity='same_LiDAR_stamp_mutually_unique_1mm_centers',
        track_ID_changes_are_not_quality_metrics=True),
    camera=camera, fusion=fusion,
    gps=dict(original_primary_gps_fix_topic_present=False, gps_message_relay_original_headers_unchanged=True,
        injected_gap_sec=[8,14], gap_lidar_inputs=[r['gps_phases']['gap']['sensor_inputs']['lidar'] for r in gps],
        gap_tracked_frames=[r['gps_phases']['gap']['tracked_frames'] for r in gps],
        pose_failures=[r['fusion_trace']['lidar_pose_failures'] for r in gps],
        first_output_after_restore_sec=[r['gps_phases']['first_tracked_after_restore_sec'] for r in gps],
        mechanism='existing_GPS_max_age_0.30s_gate_blocks_LidarProcess_and_map_output',
        local_processing_continuity_implemented=False, gps_fix_injection_claim=False),
    findings=dict(lane_transition_failure='C6 ninth semantic output at 0.9612s reached family at 1.0018s; first second contains 8',
        fusion_trace_processed_supply_accounting=True, timeout_in_supplemental_fusion_traces=0,
        primary_C1_C4_C6_trace_skipped_generations=[107,115,115],
        absolute_matching_degradation_not_waived=True, new_common_stable_classification_differences=0,
        unmatched_observations_not_counted_as_correct_or_as_GT_recall=True,
        qualitative_cases=6, raw_cloud_camera_projection=False, case_labels_are_independent_GT=False),
    measurement_failures=dict(previous_attempts_preserved=True,
        genuine_historical_C4_first_second_8_preserved=True,
        XMLRPC_shared_connection_defect_fixed=True,
        negative_control_errors=read('xmlrpc-negative-control.json')['error_count'],
        corrected_concurrent_master_and_node_calls=[400,400],
        corrected_concurrency_errors=read('xmlrpc-regression.json')['errors'],
        C2_r1_CPU_negative_control_overlap_preserved=True,
        clean_C2_r4_pass=json.loads((supp/'camera-clean-C2-r4/report.json').read_text())['passed'],
        later_success_does_not_waive_earlier_failure=True),
    parity_reuse=dict(previous_baseline='perception_camera_acceptance_followup_v1.yaml', frames=3514,
        exact_frames=3514, unmasked=True, same_weight_and_bag_SHA=True, source_fingerprints_matched=16,
        current_runtime_protected_files_matched=read('runtime-continuity.json')['protected_file_count'],
        new_GPU_parity_execution=False, previously_approved_classification_exceptions_automatically_waived=False,
        hood_person_loss_exception='previous_GT287_frame9_only_no_new_exception'),
    regression=dict(outer_build='pass', nested_build='pass', camera_tests=278, known_facade_failure=1,
        new_camera_failures=0, messages=1, hdmap=160, Main=267, lidar_core=2, jamming=94,
        measurement_and_related_tests=38, validators=4, documentation_migration='pass',
        final_PR_head_CI='must_be_verified_in_GitHub_check_runs_after_push'),
    evidence=dict(directory='config/baselines/evidence/camera_lidar_b0_v1',
        summary='summary.json', supplemental_analysis='supplemental-analysis.json',
        manifest='run-manifest.json', file_manifest='files.json', original_trial_source_and_wall_records='raw archives',
        raw_bags_and_model_weights_not_duplicated_in_archive=True),
    next_steps=['B1_same_YOLO11_raw_LiDAR_depth_connectivity_vs_existing_box_protection',
        'LiDAR_owner_local_map_separation_without_GPS', 'front_vs_three_camera_and_LiDAR_YOLO_rate_matrix_separate',
        'YOLO26_detect_then_seg_boxes_then_same_seg_masks', 'training_and_bottleneck_optimizations_then_4070_SUPER'])
for src, dest in [('protocol-299a21a/summary.json','summary.json'),
    ('protocol-299a21a/supplemental-analysis.json','supplemental-analysis.json'),
    ('protocol-299a21a/manifest.json','run-manifest.json'),
    ('fusion-supply-diagnostic.json','fusion-supply-diagnostic.json'),
    ('qualitative-review.json','qualitative-review.json'), ('runtime-continuity.json','runtime-continuity.json'),
    ('profile-comparison.png','profile-comparison.png')]:
    shutil.copyfile(raw/src,out/dest)
for bag in ('primary','shadow'):
    shutil.copytree(raw/('cases-'+bag),out/('cases-'+bag),dirs_exist_ok=True)
groups = {}
groups['raw-preliminary.tar.gz'] = [p for p in raw.iterdir() if p.is_dir() and (p.name.startswith('protocol-') and p!=fixed or p.name.startswith('smoke-'))]
for phase in ('camera','fusion','gps'):
    groups['raw-fixed-'+phase+'.tar.gz'] = [p for p in fixed.iterdir() if p.name.startswith(phase+'-')]
groups['raw-supplemental.tar.gz'] = [supp]
groups['raw-support.tar.gz'] = [p for p in raw.iterdir() if p.is_file() or p.name.startswith('cases-') or p.name=='regression']
groups['raw-support.tar.gz'] += [p for p in fixed.iterdir() if not p.name.startswith(('camera-','fusion-','gps-'))]
archives = {}
for name, paths in groups.items():
    path = out/name
    with tarfile.open(path,'w:gz',compresslevel=6) as archive:
        for p in sorted(paths):
            archive.add(p,arcname=str(p.relative_to(raw)))
    assert path.stat().st_size<95*1024*1024,(name,path.stat().st_size)
    archives[name]=dict(bytes=path.stat().st_size,sha256=digest(path))
    print(name,path.stat().st_size,flush=True)
baseline['evidence']['archives']=archives
(repo/'config/baselines/perception_camera_lidar_b0_v1.yaml').write_text(yaml.safe_dump(baseline,sort_keys=False,allow_unicode=True,width=110))
files={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in out.rglob('*') if p.is_file() and p.name!='files.json'}
(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
print('baseline and evidence written',flush=True)
