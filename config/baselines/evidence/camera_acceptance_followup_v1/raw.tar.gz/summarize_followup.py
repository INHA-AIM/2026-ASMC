import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import yaml

ws=Path('/home/aim06/projects/2026-2-kcity-autonomous-driving/2026-ai-sw-mobility-competition/asmc-camera-objects')
raw=Path('/tmp/p2a-followup/acceptance69')
out=ws/'config/baselines/evidence/camera_acceptance_followup_v1'
out.mkdir(parents=True,exist_ok=True)
baseline=ws/'config/baselines/perception_camera_acceptance_followup_v1.yaml'
r=yaml.safe_load(baseline.read_text())
r['status']='acceptance_hold'
r['implementation_revision']='faeb84a'
r['hold_reasons']=['primary_bag_two_stable_observation_classification_differences']
r['lifecycle']['gpu_input_stop_preparation_failure_recovery_reentry_passed']=True
r['lifecycle']['final_rate_source_fingerprints']='lifecycle-input-stop-final-corrected/report.json'
r['lifecycle']['later_runtime_change']='shutdown_only_stop_signal_verified_by_real_worker_regression'
r['lifecycle']['historical_failure_precise_cause_not_proven']=True
r['lifecycle']['first_second_measurement_was_not_shifted_to_first_output']=True
r['fusion']['current_status']='primary_classification_hold_shadow_current_bundle_pass'
r['fusion']['numeric_track_comparison']='diagnostic_only_same_stamp_mutually_unique_1mm_centers_own_classification_gate'
r['fusion']['runs']={}
for label in ('primary-trace','shadow-trace','primary-acceptance','shadow-acceptance'):
 s=json.loads((raw/label/'summary.json').read_text())
 r['fusion']['runs'][label]=dict(original_automatic_pass=s['pass'],
    matched_not_degraded=s['matched_not_degraded'],whole_bag_matched_not_degraded=s['whole_bag_matched_not_degraded'],
    totals=[dict(path=x['path'],repeat=x['repeat'],**x['fusion_totals'],
                 offset_p95_max_ms=x['fusion_offset_p95_max_ms'],bbox_single_publisher=x['single_bbox_publisher']) for x in s['runs']],
    stable_geometry=s['stable_old_observation_comparison'])
 if label.endswith('-trace'):
  t=json.loads((raw/label/'trace_analysis.json').read_text())
  replay=json.loads((raw/label/'continuous-replays.json').read_text())
  r['fusion']['runs'][label]['trace_integrity']=t['trace_integrity_pass']
  r['fusion']['runs'][label]['continuous_cpu_replays_passed']=all(x['returncode']==0 for x in replay.values())
  r['fusion']['runs'][label]['processed_supply']={k:{a:v[a] for a in ('processed_supply','processing_ms','skipped_generations','timeout_drops')} for k,v in t['runs'].items()}
  r['fusion']['runs'][label]['supply_deltas']={k:v['processed_supply_deltas'] for k,v in t['comparisons'].items()}
  r['fusion']['runs'][label]['all_deltas_accounted']=all(v['matched_delta_explained_by_processed_supply'] for v in t['comparisons'].values())
r['fusion']['trace_primary_numeric_gate_failure_retained']=True
r['fusion']['unmatched_or_ambiguous_observations_counted_as_success']=False
r['fusion']['traced_explanation_is_exact_proof_of_untraced_failures']=False
r['parity']=json.loads((raw/'unmasked-parity.json').read_text())
r['regression']=dict(camera_tests=278,camera_known_facade_failures=1,camera_new_failures=0,
    messages_tests=1,hdmap_tests=160,lidar_Main_tests=267,lidar_core_tests=2,jamming_tests=94,
    runtime_tests=29,analysis_tests=24,existing_ros_worker_overlay_faults_passed=True)
r['preservation']=dict(hdmap_messages_lidar_and_jamming_match_base_main=True,
    jamming_crop_defaults_unchanged=True,shared_bridge_and_master_untouched=True)
r['failed_attempts_retained']=[
    'jamming initial ROS tests and offline parity lacked nested Msg environment; corrected source order passes',
    'source SHA helper relative-path startup error; corrected absolute path and final model fault run passes']
r['evidence']=dict(directory=str(out.relative_to(ws)),raw_archive='raw.tar.gz',
                   source_fingerprint_manifest='code-files.sha256.json',file_manifest='files.json')
# Original test XMLs accompany complete logs, rather than only success counts.
for label,path in [('outer-test-results',ws/'build/test_results'),
                   ('nested-test-results',ws/'src/lidar+sensorfusion/build/test_results')]:
 target=raw/label
 if target.exists():raise RuntimeError('refusing to replace existing '+label)
 shutil.copytree(path,target)
for label in ('lifecycle-trace-01','lifecycle-trace-02','lifecycle-trace-03',
              'lifecycle-untraced-1','lifecycle-untraced-2','lifecycle-input-stop',
              'lifecycle-input-stop-final-corrected'):
 shutil.copy2(raw/label/'report.json',out/(label+'.json'))
for label in ('primary-acceptance','shadow-acceptance'):
 shutil.copy2(raw/label/'summary.json',out/(label+'.json'))
shutil.copy2(raw/'unmasked-parity.json',out/'unmasked-parity.json')
source_paths=[ws/name for name in ('tools/perception/check_model_lifecycle.py','tools/perception/lifecycle_measurements.py',
    'tools/perception/replay_camera_objects.py','tools/perception/analyze_fusion_trace.py','tools/perception/analyze_fusion_identity.py')]
source_paths+=list((ws/'src/asmc_camera/src/asmc_camera/runtime').glob('*.py'))
source_paths+=[ws/'src/asmc_camera/src/asmc_camera/nodes'/name for name in ('semantic_inference_node.py','object_detection_node.py','traffic_light_node.py')]
source_paths+=[ws/'src/asmc_camera/src/asmc_camera/detection/ultralytics_backend.py',ws/'src/asmc_camera/config/runtime/camera_region_example.yaml']
(out/'code-files.sha256.json').write_text(json.dumps({str(p.relative_to(ws)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},indent=2)+'\n')
with tarfile.open(out/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for p in sorted(raw.rglob('*')):
  if p.is_file():archive.add(p,arcname=str(p.relative_to(raw)))
manifest={p.name:dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in out.iterdir() if p.name!='files.json'}
(out/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
r['evidence']['raw_archive_sha256']=manifest['raw.tar.gz']['sha256']
r['evidence']['raw_archive_bytes']=manifest['raw.tar.gz']['bytes']
baseline.write_text(yaml.safe_dump(r,allow_unicode=True,sort_keys=False))
print(json.dumps(dict(status=r['status'],archive_bytes=manifest['raw.tar.gz']['bytes'],files=len(manifest))))
