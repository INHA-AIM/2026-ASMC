import json
import subprocess
import time
from pathlib import Path
root=Path('/evidence/acceptance69')
primary='/data/rosbags/raw/lidar_manual_20260929_130623/raw_0.bag'
shadow='/data/rosbags/raw/20260912_003803_kcity2025_shadow_static_avoid_v1_sunny_11am_wheel/bags/20260912_003803_kcity2025_shadow_static_avoid_v1_sunny_11am_wheel_0.bag'
lifecycle='/data/rosbags/hd_map_validation/20260921_174512_kcity2025_manual_route_hdmap/20260921_174512_kcity2025_manual_route_hdmap_0.bag'
stages=[]
for repeat in (1,2):
    label='lifecycle-untraced-'+str(repeat)
    stages.append((label,['python3','/root/ws/tools/perception/check_model_lifecycle.py',
        '--bag',lifecycle,'--prepare-trials','3','--no-trace','--output',str(root/label)]))
for trace in (True,False):
    for name,bag in [('primary',primary),('shadow',shadow)]:
        label=name+('-trace' if trace else '-acceptance')
        command=['python3','/root/ws/tools/perception/replay_camera_objects.py',bag,'--fusion','--hood-mask',
                 '--output',str(root/label),'--timeout','240']
        if trace:command.append('--fusion-trace')
        stages.append((label,command))
results=[]
for label,command in stages:
    started=time.monotonic()
    print(json.dumps(dict(started=label)),flush=True)
    with (root/(label+'.log')).open('w') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
    row=dict(stage=label,returncode=result.returncode,elapsed_sec=time.monotonic()-started)
    results.append(row)
    (root/'gpu-stages.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if label.endswith('-trace'):
        with (root/(label+'-analysis.log')).open('w') as stream:
            analyzed=subprocess.run(['python3','/root/ws/tools/perception/analyze_fusion_trace.py',str(root/label)],
                                    stdout=stream,stderr=subprocess.STDOUT)
        row['trace_analysis_returncode']=analyzed.returncode
        replays={}
        for path in sorted((root/label).glob('*.fusion.jsonl')):
            replayed=subprocess.run(['/root/ws/src/lidar+sensorfusion/devel/lib/Main/fusion_continuous_trace_replay',
                                     str(path),'5','3','3'],capture_output=True,text=True)
            replays[path.name]=dict(returncode=replayed.returncode,stdout=replayed.stdout,stderr=replayed.stderr)
        (root/label/'continuous-replays.json').write_text(json.dumps(replays,indent=2)+'\n')
        print(json.dumps(dict(stage=label+'-cpu',returncodes={k:v['returncode'] for k,v in replays.items()})),flush=True)
    (root/'gpu-stages.json').write_text(json.dumps(results,indent=2)+'\n')
