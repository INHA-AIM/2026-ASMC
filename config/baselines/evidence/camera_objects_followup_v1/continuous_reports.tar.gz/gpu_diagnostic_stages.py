import json, subprocess, time
from pathlib import Path
root=Path('/evidence/continuous')
primary='/data/rosbags/raw/lidar_manual_20260929_130623/raw_0.bag'
shadow='/data/rosbags/raw/20260912_003803_kcity2025_shadow_static_avoid_v1_sunny_11am_wheel/bags/20260912_003803_kcity2025_shadow_static_avoid_v1_sunny_11am_wheel_0.bag'
results=[]
for name,bag in [('primary-trace',primary),('shadow-trace',shadow)]:
    started=time.monotonic()
    with (root/(name+'.log')).open('w') as log:
        rc=subprocess.run(['python3','/root/ws/tools/perception/replay_camera_objects.py',bag,
                           '--fusion','--fusion-trace','--output',str(root/name),'--timeout','240'],
                          stdout=log,stderr=subprocess.STDOUT).returncode
    item=dict(stage=name,returncode=rc,elapsed_sec=time.monotonic()-started)
    results.append(item)
    (root/'diagnostic-stage-results.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(item),flush=True)
    summary=root/name/'summary.json'
    if not summary.exists():
        raise RuntimeError('incomplete '+name+'; inspect preserved logs')
    analysis=subprocess.run(['python3','/root/ws/tools/perception/analyze_fusion_trace.py',str(root/name)],
                            stdout=(root/(name+'-analysis.log')).open('w'),stderr=subprocess.STDOUT)
    if analysis.returncode:
        raise RuntimeError('trace accounting failed for '+name)
    replays={}
    for trace in sorted((root/name).glob('*.fusion.jsonl')):
        completed=subprocess.run(['/root/ws/src/lidar+sensorfusion/devel/lib/Main/fusion_continuous_trace_replay',
                                  str(trace),'5','3','3'],text=True,capture_output=True)
        replays[trace.stem]=dict(returncode=completed.returncode,stdout=completed.stdout,stderr=completed.stderr)
        (root/name/'continuous-replays.json').write_text(json.dumps(replays,indent=2))
    print(json.dumps({'stage':name+'-continuous','results':replays}),flush=True)
    if any(r['returncode'] for r in replays.values()):
        raise RuntimeError('continuous replay failed for '+name)
