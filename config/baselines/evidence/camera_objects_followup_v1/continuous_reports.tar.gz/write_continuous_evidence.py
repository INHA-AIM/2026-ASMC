import hashlib,json,subprocess,tarfile
from pathlib import Path
import yaml
repo=Path.cwd()
root=Path('/tmp/p2a-followup/continuous')
p=repo/'config/baselines/perception_camera_objects_followup_v1.yaml'
record=yaml.safe_load(p.read_text())
def load(path): return json.loads((root/path).read_text())
def compact(name):
 s=load(name+'/summary.json')
 return {k:s.get(k) for k in ('pass','matched_not_degraded','whole_bag_matched_not_degraded',
                             'stable_old_track_comparison','stable_old_observation_comparison')} | {
 'runs':[{k:r.get(k) for k in ('path','repeat','input_frames','output_frames','rate_hz','coverage',
             'duplicate_stamps','reverse_stamps','single_bbox_publisher','latency','fusion_totals',
             'fusion_accounting_complete','fusion_log_source','fusion_offset_p95_max_ms','track_frames','pass')}
         for r in s['runs']]}
# This host-only evidence generator uses Python 3.14; runtime tools remain 3.8-compatible.
traces={name:load(name+'/trace_analysis.json') for name in ('primary-trace','shadow-trace')}
replays={name:load(name+'/continuous-replays-with-generation.json') for name in traces}
state_reports=[json.loads(row['stdout']) for group in replays.values() for row in group.values()]
record['continuous_diagnostics']={
 'date':'2026-10-07', 'status':'diagnosis_complete_acceptance_blocked',
 'runtime_commit':'3177ffd1ba39cf07daad291d72d46faf43a07813',
 'continuous_validation_tool_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'primary_trace_capture_head':'ff88746559e22e707ff48fc815549861f486753c',
 'shadow_trace_collection_tool_commit':'c453b63a98e4465a1db33e31fb6415724a266893',
 'trace_disabled_acceptance_head':'d17ed0afc0c8071f94eb868a482e975c7b2fa575',
 'container':'asmc-camera-fusion-check', 'network':'none', 'master_port':11312,
 'cuda_other_ros_inference':'absent_at_start; shared bridge/master retained',
 'policy_changes':[],
 'scope':'Replay recorded geometric observations through matching and continuous class state transfer; not 3D projection or tracking reassociation.',
 'cpu_recorded_input_probe':load('cpu-recorded-input.replay.json'),
 'fresh_message_build':'pass; ROS-only new workspace with Main/Msg/morai_msgs',
 'fresh_continuous_replay':load('fresh-continuous-replay.json'),
 'final_regressions':{'outer_build':'pass','nested_build':'pass',
      'main_tests':{'tests':267,'failures':0},
      'camera_tests':{'tests':223,'failures':1,'known_facade_failure':load('camera-existing-facade-failure.json')},
      'messages_tests':{'tests':1,'failures':0},'jamming_tests':{'tests':94,'failures':0},
      'contracts_diagnostics_tests':{'tests':48,'failures':0},'validators':{'count':4,'failures':0}},
 'cpp_synthetic_state_tests':{'tests':5,'failures':0},
 'continuous_fixture_tests':{'tests':15,'failures':0},
 'continuous_actual_traces':replays,
 'continuous_totals':{key:sum(r[key] for r in state_reports) for key in
                      ('published_frames','matched','dropped','states','carried_checks','matcher_decisions','observations','misses','births','noise_recoveries')},
 'diagnostic_stages':load('diagnostic-stage-results.json'),
 'acceptance_stages':load('acceptance-stage-results.json'),
 'trace_summaries':{name:{run:{k:r[k] for k in ('processed_supply','processed_supply_accounting_consistent',
            'continuous_observation_complete','timeout_drops','skipped_generations','processing_ms',
            'publication_state_lag_ms','objects_without_update_in_published_frame')}
           for run,r in analysis['runs'].items()} for name,analysis in traces.items()},
 'processed_supply_comparisons':{name:analysis['comparisons'] for name,analysis in traces.items()},
 'common_source_box_comparisons':{name:analysis.get('source_box_comparisons') for name,analysis in traces.items()},
 'primary_trace_gate':compact('primary-trace'), 'shadow_trace_gate':compact('shadow-trace'),
 'primary_acceptance':compact('primary-acceptance'), 'shadow_acceptance':compact('shadow-acceptance'),
 'object_only_short_revalidation':compact('objects-smoke'), 'fault_injection':load('faults.json'),
 'strict_gates_unchanged':True,
 'original_primary_failure_reproduced':{
   'lidar_stamp_ns':1790654794688000000,
   'old_origin_lidar_ns':1790654794637000000, 'old_origin_yolo_ns':1790654794654529333,
   'old_published_class':'unknown', 'old_candidate_confirmations':4,'old_lidar_state_lag_ms':51,
   'new_origin_lidar_ns':1790654794688000000,'new_origin_yolo_ns':1790654794677862167,
   'new_published_class':'car', 'new_lidar_state_lag_ms':0,
   'old_and_new_continuous_replay_pass':True,
   'explanation':'Both paths transfer the computed state correctly; publication includes different historical observations.'},
 'prior_shadow_failure_accounting':{
   'prior_reference':'gpu_revalidation.fusion_shadow in this same record, unchanged',
   'old_minimum_matches':181, 'new_first_observed_track_frames':178,'new_first_matches':177,
   'new_first_pending_lidar':1,'new_first_dropped':0,
   'explanation':'Observed output supply and pending account for the four-match deficit; original run has no processing trace, so skipped generation identities and individual delays cannot be proven retrospectively.',
   'new_trace_verifies_processed_supply_relation':True,
   'latest_shadow_pass_does_not_erase_prior_failure':True},
 'preservation':load('preserved-worktree-check.json'),
 'retained_validation':{
   'offline_exact_3514_frames':'gpu_revalidation.offline_exact_comparison, unchanged',
   'full_object_only_ab':'gpu_revalidation.replay_ab, unchanged',
   'reason_not_repeated':'Camera backend/producer, adapter, messages and weights are byte-identical to 5868502; only Main class-copy extraction and opt-in tracing changed.'},
 'observation_failures_retained':[
   'Initial CPU probe rejected missing births from bootstrap FrameFilter paths; hooks added and repeated probe passed.',
   'Initial Python fixture shared mutable before/ready state; fixture isolated, negative controls passed.',
   'Primary trace old_1 screen interval interleaved/truncated. Structured trace remained complete. Run kept as failed; subsequent acceptance collects intact /rosout intervals plus shutdown stdout.']}
record['acceptance']['deployment_allowed']=False
record['acceptance']['next_stage_allowed']=False
record['acceptance']['continuous_diagnostics']='completed_runtime_fusion_gate_still_fails'
record['acceptance']['blockers']=[
 'Primary trace reproduces original stable classification difference at 1790654794688000000: old history lag 51ms versus new current observation. Continuous propagation is correct in both.',
 'Latest trace-disabled primary acceptance still has one stable geometric classification regression at 1790654820956000000. Distinct processing/track histories remain; not waived by CPU replay.',
 'Previous shadow 177 < 181 failure retained despite latest shadow passing; frame-selection variability not removed or reclassified as acceptance.']
record['status']='continuous_diagnosis_complete_acceptance_blocked'
record['verified_date']='2026-10-07'
# Archive the full additional runs and all failed controls without modifying prior archives.
archive=repo/'config/baselines/evidence/camera_objects_followup_v1/continuous_reports.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for child in sorted(root.iterdir()):
  tar.add(child,arcname=child.name)
new=record['continuous_diagnostics']
new['archive']=str(archive.relative_to(repo))
new['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
new['archive_bytes']=archive.stat().st_size
p.write_text(yaml.safe_dump(record,allow_unicode=True,sort_keys=False))
print(json.dumps({'archive_bytes':archive.stat().st_size,'sha256':new['archive_sha256'],'totals':new['continuous_totals']},indent=2))
