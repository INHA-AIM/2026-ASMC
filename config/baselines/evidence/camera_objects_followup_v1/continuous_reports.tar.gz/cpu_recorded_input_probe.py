import os, signal, subprocess, time
from pathlib import Path
import rospy
from sensor_msgs.msg import CompressedImage
from asmc_msgs.msg import CameraObjectBoxArray
root=Path('/evidence/continuous')
rospy.init_node('continuous_cpu_probe',disable_signals=True)
rospy.set_param('/use_sim_time', True)
pub=rospy.Publisher('/perception/camera/objects', CameraObjectBoxArray,queue_size=5)
def frame(image):
    pub.publish(CameraObjectBoxArray(header=image.header,valid=True,image_width=1280,image_height=720))
sub=rospy.Subscriber('/image_jpeg/compressed',CompressedImage,frame,queue_size=10)
log=(root/'cpu-recorded-input.main.log').open('w')
p=subprocess.Popen(['roslaunch','Main','main.launch','start_yolo:=false','rviz:=false',
                    'start_velodyne_driver:=false','fusion_trace_path:=/evidence/continuous/cpu-recorded-input.fusion.jsonl'],
                   stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
try:
    deadline=time.monotonic()+25
    while not pub.get_num_connections():
        assert time.monotonic()<deadline and p.poll() is None
        time.sleep(.05)
    subprocess.run(['rosbag','play','--clock','--quiet','--delay=1','--duration=7',
                    '/data/rosbags/raw/lidar_manual_20260929_130623/raw_0.bag'],check=True,
                    stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    time.sleep(.5)
finally:
    os.killpg(p.pid,signal.SIGINT);p.wait(timeout=15);log.close()
