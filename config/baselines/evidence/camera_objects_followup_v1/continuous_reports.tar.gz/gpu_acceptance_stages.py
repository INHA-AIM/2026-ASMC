import json, subprocess, time
from pathlib import Path
root=Path('/evidence/continuous')
primary='/data/rosbags/raw/lidar_manual_20260929_130623/raw_0.bag'
shadow='/data/rosbags/raw/20260912_003803_kcity2025_shadow_static_avoid_v1_sunny_11am_wheel/bags/20260912_003803_kcity2025_shadow_static_avoid_v1_sunny_11am_wheel_0.bag'
front='/data/rosbags/hd_map_validation/20260921_174512_kcity2025_manual_route_hdmap/20260921_174512_kcity2025_manual_route_hdmap_0.bag'
results=[]
commands=[('primary-acceptance',['python3','/root/ws/tools/perception/replay_camera_objects.py',primary,'--fusion','--output',str(root/'primary-acceptance')]),
          ('shadow-acceptance',['python3','/root/ws/tools/perception/replay_camera_objects.py',shadow,'--fusion','--output',str(root/'shadow-acceptance')]),
          ('objects-smoke',['python3','/root/ws/tools/perception/replay_camera_objects.py',front,'--path','new','--play-duration','10','--acceptance','--output',str(root/'objects-smoke')]),
          ('faults',['python3','/root/ws/tools/perception/check_camera_object_faults.py','--output',str(root/'faults.json')])]
for name,command in commands:
    started=time.monotonic()
    with (root/(name+'.log')).open('w') as log:
        rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
    item=dict(stage=name,returncode=rc,elapsed_sec=time.monotonic()-started)
    results.append(item); (root/'acceptance-stage-results.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(item),flush=True)
    if name.endswith('acceptance') and not (root/name/'summary.json').exists():
        raise RuntimeError('incomplete '+name)
