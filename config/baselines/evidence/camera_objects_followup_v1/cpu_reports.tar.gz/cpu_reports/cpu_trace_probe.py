import json, signal, subprocess, time
from pathlib import Path
import cv2
import numpy as np
import rospy
from std_msgs.msg import Header
from sensor_msgs.msg import CompressedImage
from sensor_msgs import point_cloud2
from asmc_msgs.msg import CameraObjectBoxArray
rospy.init_node('cpu_trace_probe', disable_signals=True)
image = rospy.Publisher('/image_jpeg/compressed', CompressedImage, queue_size=5)
objects = rospy.Publisher('/perception/camera/objects', CameraObjectBoxArray, queue_size=5)
cloud = rospy.Publisher('/velodyne_points', point_cloud2.PointCloud2, queue_size=5)
log = open('/evidence/cpu_callbacks.main.log', 'w')
p = subprocess.Popen(['roslaunch','Main','main.launch','start_yolo:=false','rviz:=false',
                      'fusion_trace_path:=/evidence/cpu_callbacks.fusion.jsonl'], stdout=log, stderr=subprocess.STDOUT)
try:
    deadline = time.monotonic()+20
    while not all(pub.get_num_connections() for pub in (image,objects,cloud)):
        assert p.poll() is None and time.monotonic()<deadline, 'nodes not ready'
        time.sleep(.1)
    _, jpeg = cv2.imencode('.jpg', np.zeros((720,1280,3),np.uint8))
    for i in range(5):
        header=Header(stamp=rospy.Time.now(),frame_id='camera_front',seq=i)
        image.publish(CompressedImage(header=header,format='jpeg',data=jpeg.tobytes()))
        objects.publish(CameraObjectBoxArray(header=header,valid=True,image_width=1280,image_height=720))
        cloud.publish(point_cloud2.create_cloud_xyz32(Header(stamp=header.stamp,frame_id='velodyne'),[(1.,0.,-1.)]))
        time.sleep(.2)
    time.sleep(.3)
finally:
    p.send_signal(signal.SIGINT)
    p.wait(timeout=15)
    log.close()
rows=[json.loads(line) for line in Path('/evidence/cpu_callbacks.fusion.jsonl').read_text().splitlines()]
counts={kind: sum(r['event']==kind for r in rows) for kind in ('camera_input','yolo_input','lidar_input','lidar_process_start','lidar_process_end','fusion_summary')}
assert all(counts.values()),counts
assert rows[-1]['event']=='fusion_summary'
assert all(r['boxes']==[] for r in rows if r['event']=='yolo_input')
print(counts)
Path('/evidence/cpu_callbacks.result.json').write_text(json.dumps({'pass':True,'counts':counts}))
