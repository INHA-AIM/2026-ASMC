import collections
import hashlib
import json
import os
import re
import tarfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

BASE = Path('/home/aim06/projects/2026-2-kcity-autonomous-driving/2026-ai-sw-mobility-competition')
OUT = BASE / 'artifacts/camera-training-audit/20261008'
OUT.mkdir(parents=True, exist_ok=True)
DATA = BASE / 'data/datasets'
report = {'audit_scope': 'filename inventory plus stratified decoded samples; not full image/annotation acceptance', 'capture': {}, 'aim': {}}

capture_runs = {}
for run in sorted(DATA.iterdir()):
    if not (run / 'dataset.json').exists():
        continue
    meta = json.loads((run / 'dataset.json').read_text())
    entry = {'declared_frames': meta.get('frame_count'), 'channels': {}}
    for modality in ('intensity', 'semantic', 'instance', 'depth'):
        for view in ('front', 'left', 'right', 'traffic_light'):
            folder = run / 'frames' / modality / view
            entry['channels'][modality + '/' + view] = {p.stem for p in folder.glob('*.png')}
    entry['rgb_instance_semantic_pairs'] = {
        v: len(entry['channels']['intensity/' + v] & entry['channels']['instance/' + v] & entry['channels']['semantic/' + v])
        for v in ('front', 'left', 'right', 'traffic_light')}
    entry['channel_counts'] = {k: len(v) for k, v in entry['channels'].items()}
    capture_runs[run.name] = entry
report['capture']['runs'] = {k: {x: y for x, y in v.items() if x != 'channels'} for k, v in capture_runs.items()}
report['capture']['paired_totals_by_view'] = dict(sum((collections.Counter(v['rgb_instance_semantic_pairs']) for v in capture_runs.values()), collections.Counter()))
print('capture channel inventory finished', flush=True)

pattern = re.compile(r'^(\S+)\s+([-+.\deE]+)\s+([-+.\deE]+)\s+([-+.\deE]+)\s+([-+.\deE]+)\s+(\S+)\s+\((\d+),\s*(\d+),\s*(\d+),\s*(\d+)\)$')
bbox_frames = {}
labels = collections.Counter()
byview = collections.Counter()
missing_rgb = collections.Counter()
format_errors = []
meta_path = Path('/mnt/e/asmc_capture_export_20260911/meta.tar.xz')
with tarfile.open(meta_path, 'r:xz') as archive:
    for member in archive:
        if not member.name.endswith('_BBox2D.txt'):
            continue
        _, run, view, filename = member.name.split('/')
        stem = filename.removesuffix('_BBox2D.txt')
        rows = []
        for line in archive.extractfile(member).read().decode('utf-8-sig').splitlines():
            if not line.strip():
                continue
            match = pattern.match(line)
            if not match:
                format_errors.append({'path': member.name, 'line': line})
                continue
            values = match.groups()
            row = {'label': values[0], 'xyxy': list(map(float, values[1:5])), 'actor_id': values[5], 'rgba': list(map(int, values[6:10]))}
            rows.append(row)
            labels[row['label']] += 1
        byview[view] += 1
        if not (DATA / run / 'frames/intensity' / view / (stem + '.png')).exists():
            missing_rgb[view] += 1
        bbox_frames[(run, view, stem)] = rows
report['capture'].update(meta_sha256=hashlib.sha256(meta_path.read_bytes()).hexdigest(), bbox_files_by_view=dict(byview), bbox_rows_by_label=dict(labels), bbox_files_missing_extracted_rgb=dict(missing_rgb), bbox_format_errors=format_errors)

groups = collections.defaultdict(list)
for key, rows in bbox_frames.items():
    if rows and key[0] in capture_runs and key[2] in capture_runs[key[0]]['channels']['instance/' + key[1]]:
        groups[key[:2]].append(key)
selected = set()
for keys in groups.values():
    keys.sort()
    selected.update(keys[i] for i in {0, len(keys) // 2, len(keys) - 1})
# Ensure each GT class has a large-area sample for each camera where available.
for view in ('front', 'left', 'right', 'traffic_light'):
    for label in labels:
        eligible = [(max((max(0, r['xyxy'][2]-r['xyxy'][0])*max(0, r['xyxy'][3]-r['xyxy'][1]) for r in rows if r['label'] == label), default=0), key)
                    for key, rows in bbox_frames.items() if key[1] == view and key in set(groups.get(key[:2], []))]
        if eligible:
            area, key = max(eligible)
            if area:
                selected.add(key)

samples = []
counts = collections.Counter()
gallery = []
for index, key in enumerate(sorted(selected)):
    run, view, stem = key
    root = DATA / run / 'frames'
    rgb_path = root / 'intensity' / view / (stem + '.png')
    instance_path = root / 'instance' / view / (stem + '.png')
    semantic_path = root / 'semantic' / view / (stem + '.png')
    if not all(p.exists() for p in (rgb_path, instance_path, semantic_path)):
        continue
    rgb = Image.open(rgb_path).convert('RGB')
    inst = np.array(Image.open(instance_path).convert('RGBA'))
    sem = np.array(Image.open(semantic_path).convert('RGB'))
    if inst.shape[:2] != (rgb.height, rgb.width) or sem.shape[:2] != inst.shape[:2]:
        counts['shape_errors'] += 1
        continue
    records = []
    overlay = np.array(rgb).copy()
    for row in bbox_frames[key]:
        bitmap = np.all(inst == np.array(row['rgba'], dtype=np.uint8), axis=2)
        yy, xx = np.nonzero(bitmap)
        pixels = int(len(xx))
        entry = dict(row, visible_mask_pixels=pixels)
        counts['box_rows_checked'] += 1
        counts['visible_mask_rows' if pixels else 'no_visible_mask_rows'] += 1
        if pixels:
            entry['visible_mask_xyxy'] = [int(xx.min()), int(yy.min()), int(xx.max()+1), int(yy.max()+1)]
            colors, freq = np.unique(sem[bitmap], axis=0, return_counts=True)
            dominant = int(freq.argmax())
            entry['semantic_dominant_rgb'] = colors[dominant].tolist()
            entry['semantic_dominant_fraction'] = float(freq[dominant] / pixels)
            overlay[bitmap] = (overlay[bitmap] * .55 + np.array([0, 255, 60]) * .45).astype(np.uint8)
        records.append(entry)
    samples.append({'run': run, 'view': view, 'frame': stem, 'shape': [rgb.height, rgb.width], 'rows': records})
    if any(r['label'] == 'Obstacle' and r['visible_mask_pixels'] > 100 for r in records) and len(gallery) < 12:
        out = Image.fromarray(overlay)
        draw = ImageDraw.Draw(out)
        for r in records:
            if r['visible_mask_pixels']:
                draw.rectangle(r['visible_mask_xyxy'], outline='red', width=2)
        name = f'{view}-{run}-{stem}.jpg'
        out.save(OUT / name)
        gallery.append({'image': name, 'run': run, 'view': view, 'frame': stem, 'rows': records})
    if (index+1) % 30 == 0:
        print('decoded sample frames', index+1, flush=True)
report['capture']['decoded_sample_counts'] = dict(counts, frames=len(samples))
report['capture']['decoded_samples'] = samples
report['capture']['gallery'] = gallery

aim_root = Path('/mnt/d/asmc_aim/dataset')
tags = collections.Counter()
bycamera = collections.Counter()
basenames = collections.Counter()
metadata = []
camera_samples = {}
for folder, dirs, files in os.walk(aim_root):
    dirs[:] = [d for d in dirs if d not in ('software_snapshot', '.git', '__pycache__', 'node_modules')]
    camera = next((p for p in Path(folder).parts if re.fullmatch('CAMERA_[1-4]', p)), None)
    for name in files:
        basenames[name] += 1 if name.endswith('.json') else 0
        if camera:
            match = re.search(r'_(Intensity|Semantic|Instance|Depth|BBox2D|BBox3D)\.(png|txt)$', name)
            if match:
                tag = match[1]
                tags[tag] += 1
                bycamera[camera + '/' + tag] += 1
                if tag == 'Intensity' and camera not in camera_samples:
                    path = Path(folder) / name
                    image = Image.open(path)
                    camera_samples[camera] = {'path': str(path), 'shape': list(image.size)}
        if name == 'NATIVE_CAPTURE_RESULT.json':
            path = Path(folder) / name
            data = json.loads(path.read_text())
            metadata.append({'path': str(path), 'training_visible': data.get('training_visible'), 'postprocess_status': data.get('postprocess_status'), 'physical_simultaneity_verified': data.get('physical_simultaneity_verified')})
report['aim'] = {'camera_channels': dict(tags), 'camera_channels_by_id': dict(bycamera), 'camera_samples': camera_samples, 'native_result_statuses': metadata, 'common_json_names': basenames.most_common(20), 'scope': 'excludes software snapshots; PNGs counted by names, not deduplicated or all decoded'}
(OUT / 'audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'capture_paired_totals': report['capture']['paired_totals_by_view'], 'bbox_files': dict(byview), 'bbox_rows': dict(labels), 'decoded': report['capture']['decoded_sample_counts'], 'aim_channels': dict(tags), 'aim_native_results': len(metadata), 'output': str(OUT)}, ensure_ascii=False, indent=2), flush=True)
